# JuliaConvGRU

https://iwasnothing.medium.com/time-series-prediction-feat-introduction-of-julia-78ed6897910c

Module File: ConvGRU/src/ConvGRU.jl
Notebook to run: loading.ipynb
